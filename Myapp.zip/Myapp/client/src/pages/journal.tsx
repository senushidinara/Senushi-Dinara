import React, { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Brain, Heart, User, Bot, Send, Lightbulb, Shield, Settings, Paperclip, Smile, AlertCircle } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import type { Message, Conversation } from '@shared/schema';
import { cn } from '@/lib/utils';

interface ConversationStarter {
  text: string;
  icon?: string;
}

const conversationStarters: ConversationStarter[] = [
  { text: "I'm feeling stressed about..." },
  { text: "I'm grateful for..." },
  { text: "Today I accomplished..." },
  { text: "I'm worried about..." },
];

export default function Journal() {
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const queryClient = useQueryClient();

  // Create initial conversation
  const createConversationMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/conversations', {
        userId: 'default_user'
      });
      return await response.json();
    },
    onSuccess: (conversation: Conversation) => {
      setCurrentConversationId(conversation.id);
    }
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async ({ conversationId, content }: { conversationId: string; content: string }) => {
      const response = await apiRequest('POST', `/api/conversations/${conversationId}/messages`, {
        content
      });
      return await response.json();
    },
    onMutate: () => {
      setIsTyping(true);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/conversations', currentConversationId, 'messages'] });
      setMessage('');
      setIsTyping(false);
    },
    onError: () => {
      setIsTyping(false);
    }
  });

  // Fetch messages for current conversation
  const { data: messages = [], isLoading: messagesLoading, error: messagesError } = useQuery({
    queryKey: ['/api/conversations', currentConversationId, 'messages'],
    enabled: !!currentConversationId,
    refetchInterval: false,
  }) as { data: Message[], isLoading: boolean, error: Error | null };

  // Create conversation on mount
  useEffect(() => {
    if (!currentConversationId && !createConversationMutation.isPending) {
      createConversationMutation.mutate();
    }
  }, []);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + 'px';
    }
  }, [message]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = () => {
    const trimmedMessage = message.trim();
    if (!trimmedMessage || !currentConversationId || sendMessageMutation.isPending) return;

    sendMessageMutation.mutate({
      conversationId: currentConversationId,
      content: trimmedMessage
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleStarterClick = (starter: string) => {
    setMessage(starter.replace(/"/g, ''));
    textareaRef.current?.focus();
  };

  const formatTime = (timestamp: string | Date) => {
    return new Date(timestamp).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  if (createConversationMutation.isPending) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-cream-50 to-sage-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-sage-400 to-ocean-400 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
            <Brain className="h-8 w-8 text-white" />
          </div>
          <p className="text-gray-600">Initializing your safe space...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-cream-50 to-sage-50 font-sans">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-sage-400 to-ocean-400 rounded-full flex items-center justify-center shadow-md">
                <Brain className="h-5 w-5 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-800">Nero</h1>
                <p className="text-sm text-gray-600">Your AI Therapeutic Journal</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span>Online</span>
              </div>
              <Button variant="ghost" size="sm">
                <Settings className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-6">
        {/* Welcome Message */}
        {messages.length === 0 && !messagesLoading && (
          <div className="text-center mb-8">
            <Card className="bg-white/60 backdrop-blur-sm shadow-sm border-sage-100">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-gradient-to-br from-sage-400 to-ocean-400 rounded-full flex items-center justify-center shadow-lg mx-auto mb-4">
                  <Heart className="h-6 w-6 text-white" />
                </div>
                <h2 className="text-xl font-semibold text-gray-800 mb-2">Welcome to Your Safe Space</h2>
                <p className="text-gray-600 leading-relaxed">
                  I'm Nero, your AI therapeutic companion. Share your thoughts, feelings, or anything on your mind. 
                  This is a judgment-free zone where you can express yourself freely.
                </p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Error State */}
        {messagesError && (
          <Alert className="mb-6 border-red-200 bg-red-50">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Having trouble loading your conversation. Please refresh the page or try again.
            </AlertDescription>
          </Alert>
        )}

        {/* Chat Messages */}
        <div className="space-y-6 mb-6">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={cn(
                "flex items-start space-x-3 animate-fade-in",
                msg.role === "user" ? "flex-row-reverse space-x-reverse" : ""
              )}
            >
              <div className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center shadow-sm flex-shrink-0",
                msg.role === "user" 
                  ? "bg-gradient-to-br from-lavender-400 to-ocean-300"
                  : "bg-gradient-to-br from-sage-400 to-ocean-400"
              )}>
                {msg.role === "user" ? (
                  <User className="h-4 w-4 text-white" />
                ) : (
                  <Bot className="h-4 w-4 text-white" />
                )}
              </div>
              <div className="flex-1">
                <div className={cn(
                  "shadow-sm rounded-2xl p-4 max-w-3xl",
                  msg.role === "user" 
                    ? "bg-gradient-to-r from-lavender-100 to-ocean-100 rounded-tr-md ml-auto"
                    : "bg-white rounded-tl-md"
                )}>
                  <p className="text-gray-800 leading-relaxed whitespace-pre-wrap">
                    {msg.content}
                  </p>
                </div>
                <div className={cn(
                  "flex items-center space-x-2 mt-2",
                  msg.role === "user" ? "mr-2 justify-end" : "ml-2"
                )}>
                  <span className="text-xs text-gray-500">
                    {formatTime(msg.timestamp)}
                  </span>
                  <Badge variant="outline" className={cn(
                    "text-xs",
                    msg.role === "user" 
                      ? "text-ocean-500 border-ocean-200"
                      : "text-sage-500 border-sage-200"
                  )}>
                    {msg.role === "user" ? "You" : "Nero"}
                  </Badge>
                </div>
              </div>
            </div>
          ))}

          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex items-start space-x-3 animate-fade-in">
              <div className="w-8 h-8 bg-gradient-to-br from-sage-400 to-ocean-400 rounded-full flex items-center justify-center shadow-sm flex-shrink-0">
                <Bot className="h-4 w-4 text-white" />
              </div>
              <div className="flex-1">
                <div className="bg-white shadow-sm rounded-2xl rounded-tl-md p-4 max-w-xs">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-sage-400 rounded-full animate-bounce-dots"></div>
                    <div className="w-2 h-2 bg-sage-400 rounded-full animate-bounce-dots" style={{ animationDelay: '0.2s' }}></div>
                    <div className="w-2 h-2 bg-sage-400 rounded-full animate-bounce-dots" style={{ animationDelay: '0.4s' }}></div>
                  </div>
                </div>
                <div className="flex items-center space-x-2 mt-2 ml-2">
                  <Badge variant="outline" className="text-xs text-sage-500 border-sage-200">
                    Nero is typing...
                  </Badge>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Conversation Starters */}
        {messages.length === 0 && !messagesLoading && (
          <div className="mb-6">
            <Card className="bg-sage-50/50 border-sage-200/50">
              <CardContent className="p-4">
                <h3 className="text-sm font-medium text-sage-700 mb-3 flex items-center">
                  <Lightbulb className="h-4 w-4 mr-2" />
                  Conversation starters
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {conversationStarters.map((starter, index) => (
                    <Button
                      key={index}
                      variant="ghost"
                      className="text-left p-3 bg-white/60 hover:bg-white/80 rounded-lg transition-colors text-sm text-gray-700 hover:text-gray-800 border border-sage-100 h-auto justify-start"
                      onClick={() => handleStarterClick(starter.text)}
                    >
                      {starter.text}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </main>

      {/* Message Input */}
      <div className="sticky bottom-0 bg-gradient-to-t from-cream-50 to-transparent pt-6 pb-4">
        <div className="max-w-4xl mx-auto px-4">
          <Card className="bg-white/80 backdrop-blur-md shadow-lg border-sage-200/50">
            <CardContent className="p-4">
              <div className="flex items-end space-x-3">
                <div className="flex-1">
                  <Textarea
                    ref={textareaRef}
                    placeholder="Share what's on your mind... I'm here to listen."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyDown={handleKeyPress}
                    className="resize-none border-0 focus:ring-0 focus:outline-none bg-transparent text-gray-800 placeholder-gray-500 text-base leading-6 shadow-none"
                    rows={1}
                    maxLength={2000}
                  />
                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-center space-x-3 text-gray-500">
                      <Button variant="ghost" size="sm" className="p-1 h-auto">
                        <Paperclip className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm" className="p-1 h-auto">
                        <Smile className="h-4 w-4" />
                      </Button>
                    </div>
                    <span className="text-xs text-gray-400">
                      {message.length}/2000
                    </span>
                  </div>
                </div>
                <Button
                  onClick={handleSendMessage}
                  disabled={!message.trim() || sendMessageMutation.isPending}
                  className="bg-gradient-to-r from-sage-400 to-ocean-400 hover:from-sage-500 hover:to-ocean-500 text-white rounded-xl px-6 py-3 font-medium transition-all duration-200 shadow-md hover:shadow-lg"
                >
                  <Send className="h-4 w-4 mr-2" />
                  Send
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Privacy Notice */}
          <p className="text-xs text-gray-500 text-center mt-3 px-4">
            <Shield className="inline h-3 w-3 mr-1" />
            Your conversations are private and secure. Nero is here to support, not replace professional therapy.
          </p>
        </div>
      </div>
    </div>
  );
}
