#!/usr/bin/env python3
"""
Nero AI Journal - Chat History Synchronization with Notion
Automatically syncs chat conversations from the Node.js app to Notion for analytics
"""

import os
import requests
import json
from datetime import datetime
from typing import Dict, List, Any
from notion_client import Client
from simple_analyzer import SimpleJournalAnalyzer

class ChatHistorySync:
    def __init__(self):
        self.notion = Client(auth=os.getenv("NOTION_TOKEN"))
        self.database_id = os.getenv("NOTION_DATABASE_ID")
        self.analyzer = SimpleJournalAnalyzer()
        self.node_api_base = "http://localhost:5000/api"
        
    def fetch_conversations(self) -> List[Dict]:
        """Fetch all conversations from Node.js API"""
        try:
            response = requests.get(f"{self.node_api_base}/conversations?userId=default_user")
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Error fetching conversations: {response.status_code}")
                return []
        except Exception as e:
            print(f"Error connecting to Node.js API: {str(e)}")
            return []
    
    def fetch_messages(self, conversation_id: str) -> List[Dict]:
        """Fetch messages for a specific conversation"""
        try:
            response = requests.get(f"{self.node_api_base}/conversations/{conversation_id}/messages")
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Error fetching messages for {conversation_id}: {response.status_code}")
                return []
        except Exception as e:
            print(f"Error fetching messages: {str(e)}")
            return []
    
    def sync_conversation_to_notion(self, conversation: Dict, messages: List[Dict]) -> bool:
        """Sync a complete conversation to Notion with analysis"""
        try:
            # Extract user messages for analysis
            user_messages = [msg['content'] for msg in messages if msg['role'] == 'user']
            full_user_text = ' '.join(user_messages)
            
            if not full_user_text.strip():
                return False
            
            # Analyze the complete conversation
            analysis = self.analyzer.analyze_text(full_user_text)
            
            # Create conversation summary
            ai_messages = [msg['content'] for msg in messages if msg['role'] == 'assistant']
            conversation_summary = {
                'conversation_id': conversation['id'],
                'date': conversation['createdAt'],
                'user_message_count': len(user_messages),
                'ai_message_count': len(ai_messages),
                'full_conversation': self._format_conversation(messages),
                'user_text_combined': full_user_text,
                'analysis': analysis
            }
            
            # Create title
            title = f"Chat Session - {datetime.fromisoformat(conversation['createdAt'].replace('Z', '+00:00')).strftime('%Y-%m-%d %H:%M')} - {analysis['mood'].title()} mood"
            
            # Prepare Notion data
            notion_data = {
                "Name": {
                    "title": [{"text": {"content": title}}]
                }
            }
            
            # Add analysis if columns exist
            if self._check_property_exists('Analysis'):
                analysis_text = f"""
Conversation Analysis:
- Mood: {analysis['mood'].title()}
- Energy: {analysis['energy'].title()}
- Stress: {analysis['stress'].title()}
- Emotions: {', '.join(analysis['emotions']).title()}
- Motivation: {analysis['motivation']}

Message Count: {len(user_messages)} user messages, {len(ai_messages)} AI responses
Conversation ID: {conversation['id']}
"""
                notion_data['Analysis'] = {
                    "rich_text": [{"text": {"content": analysis_text.strip()}}]
                }
            
            if self._check_property_exists('Full Conversation'):
                notion_data['Full Conversation'] = {
                    "rich_text": [{"text": {"content": conversation_summary['full_conversation'][:2000]}}]
                }
            
            if self._check_property_exists('Date'):
                notion_data['Date'] = {
                    "date": {"start": datetime.fromisoformat(conversation['createdAt'].replace('Z', '+00:00')).strftime('%Y-%m-%d')}
                }
            
            # Create page
            response = self.notion.pages.create(
                parent={"database_id": self.database_id},
                properties=notion_data
            )
            
            print(f"✅ Synced conversation {conversation['id'][:8]}... to Notion")
            return True
            
        except Exception as e:
            print(f"❌ Error syncing conversation: {str(e)}")
            return False
    
    def _format_conversation(self, messages: List[Dict]) -> str:
        """Format conversation for readable display"""
        formatted = []
        for msg in messages:
            timestamp = datetime.fromisoformat(msg['timestamp'].replace('Z', '+00:00')).strftime('%H:%M')
            role = "You" if msg['role'] == 'user' else "Nero"
            formatted.append(f"[{timestamp}] {role}: {msg['content']}")
        return '\n\n'.join(formatted)
    
    def _check_property_exists(self, property_name: str) -> bool:
        """Check if a property exists in the Notion database"""
        try:
            db_info = self.notion.databases.retrieve(database_id=self.database_id)
            return property_name in db_info.get('properties', {})
        except:
            return False
    
    def sync_all_conversations(self) -> Dict[str, int]:
        """Sync all conversations from Node.js to Notion"""
        print("🔄 Starting chat history synchronization...")
        
        conversations = self.fetch_conversations()
        if not conversations:
            print("❌ No conversations found or API unavailable")
            return {'synced': 0, 'failed': 0}
        
        synced = 0
        failed = 0
        
        for conversation in conversations:
            print(f"📥 Processing conversation {conversation['id'][:8]}...")
            messages = self.fetch_messages(conversation['id'])
            
            if messages:
                if self.sync_conversation_to_notion(conversation, messages):
                    synced += 1
                else:
                    failed += 1
            else:
                print(f"⚠️  No messages found for conversation {conversation['id'][:8]}")
                failed += 1
        
        return {'synced': synced, 'failed': failed}

def main():
    """Main synchronization function"""
    print("🧠 Nero AI Journal - Chat History Sync")
    print("=" * 50)
    
    # Check credentials
    if not os.getenv("NOTION_TOKEN") or not os.getenv("NOTION_DATABASE_ID"):
        print("❌ Missing Notion credentials")
        return
    
    sync = ChatHistorySync()
    results = sync.sync_all_conversations()
    
    print(f"\n📊 Synchronization Results:")
    print(f"   ✅ Successfully synced: {results['synced']} conversations")
    print(f"   ❌ Failed: {results['failed']} conversations")
    
    if results['synced'] > 0:
        print(f"\n💡 Your chat history is now available in Notion for analysis!")
        print(f"   You can create charts, track mood patterns, and analyze trends.")
    
    print(f"\n{'='*50}")

if __name__ == "__main__":
    main()