#!/usr/bin/env python3
"""
Create demo conversations in the Node.js app for testing analytics
"""

import requests
import time
import random

def create_demo_conversations():
    """Create several demo conversations for analytics testing"""
    
    base_url = "http://localhost:5000/api"
    
    demo_entries = [
        "I'm feeling really excited about this new project! I want to build something amazing that helps people with their mental health.",
        "Today was overwhelming at work. Too many deadlines and I feel stressed and anxious about everything.",
        "I had a calm and peaceful morning. Meditated for 20 minutes and feel centered and grateful.",
        "Feeling a bit down today. The weather is gloomy and I'm worried about my future career prospects.",
        "Super motivated today! I want to learn new skills and push myself to achieve my goals this month.",
        "Had trouble sleeping last night. Feel tired and foggy, but determined to make the best of today.",
        "Grateful for my friends and family. Feeling loved and supported, which gives me confidence.",
        "Frustrated with myself for procrastinating. I need to be more disciplined and focused on my priorities."
    ]
    
    print("🎭 Creating demo conversations for analytics testing...")
    
    for i, entry in enumerate(demo_entries):
        try:
            # Create conversation
            conv_response = requests.post(f"{base_url}/conversations", 
                                        json={"userId": "default_user"})
            
            if conv_response.status_code == 200:
                conv_data = conv_response.json()
                conv_id = conv_data['id']
                
                # Send message
                msg_response = requests.post(f"{base_url}/conversations/{conv_id}/messages",
                                           json={"content": entry})
                
                if msg_response.status_code == 200:
                    print(f"✅ Created conversation {i+1}: {entry[:50]}...")
                else:
                    print(f"❌ Failed to send message {i+1}")
            else:
                print(f"❌ Failed to create conversation {i+1}")
            
            # Small delay between requests
            time.sleep(1)
            
        except Exception as e:
            print(f"❌ Error creating conversation {i+1}: {str(e)}")
    
    print(f"🎉 Demo conversations created! Now you can test the analytics.")

if __name__ == "__main__":
    create_demo_conversations()