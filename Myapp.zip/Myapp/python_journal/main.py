#!/usr/bin/env python3
"""
Nero AI Journal - Neuroscience-powered mental health analysis
Analyzes journal entries and saves structured data to Notion database
"""

import os
import re
import json
from datetime import datetime
from typing import Dict, List, Any
from notion_client import Client
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class JournalAnalyzer:
    def __init__(self):
        # Initialize Notion client
        self.notion = Client(auth=os.getenv("NOTION_TOKEN"))
        self.database_id = os.getenv("NOTION_DATABASE_ID")
        
        # Analysis patterns
        self.mood_patterns = {
            'happy': ['happy', 'joy', 'excited', 'cheerful', 'elated', 'content', 'pleased'],
            'sad': ['sad', 'depressed', 'down', 'blue', 'melancholy', 'grief', 'sorrow'],
            'anxious': ['anxious', 'worried', 'nervous', 'stressed', 'panic', 'fear', 'overwhelmed'],
            'angry': ['angry', 'mad', 'furious', 'irritated', 'frustrated', 'rage'],
            'calm': ['calm', 'peaceful', 'serene', 'relaxed', 'tranquil'],
            'confused': ['confused', 'lost', 'unclear', 'puzzled', 'bewildered']
        }
        
        self.energy_patterns = {
            'high': ['energetic', 'motivated', 'pumped', 'active', 'vibrant', 'dynamic'],
            'medium': ['okay', 'decent', 'moderate', 'balanced', 'stable'],
            'low': ['tired', 'exhausted', 'drained', 'fatigued', 'sluggish', 'weary']
        }
        
        self.stress_patterns = {
            'high': ['overwhelmed', 'stressed', 'pressure', 'burden', 'intense', 'chaotic'],
            'medium': ['busy', 'challenged', 'stretched', 'demanding'],
            'low': ['relaxed', 'easy', 'manageable', 'comfortable', 'peaceful']
        }
        
        self.clarity_patterns = {
            'clear': ['clear', 'focused', 'sharp', 'lucid', 'coherent', 'organized'],
            'foggy': ['foggy', 'unclear', 'confused', 'scattered', 'muddled'],
            'cloudy': ['cloudy', 'hazy', 'dim', 'blurry', 'uncertain']
        }
        
        self.sleep_patterns = {
            'good': ['slept well', 'rested', 'refreshed', 'good sleep', 'peaceful sleep'],
            'poor': ['restless', 'insomnia', 'sleepless', 'tossed', 'turned', 'nightmare'],
            'okay': ['decent sleep', 'okay sleep', 'average sleep']
        }
        
        self.emotion_tags = [
            'grateful', 'hopeful', 'proud', 'lonely', 'guilty', 'ashamed', 
            'confident', 'insecure', 'loved', 'rejected', 'optimistic', 
            'pessimistic', 'creative', 'stuck', 'determined', 'defeated'
        ]

    def analyze_text(self, text: str) -> Dict[str, Any]:
        """Analyze journal entry text and extract psychological markers"""
        text_lower = text.lower()
        
        analysis = {
            'original_text': text,
            'date': datetime.now().isoformat(),
            'mood': self._detect_mood(text_lower),
            'energy': self._detect_energy(text_lower),
            'stress': self._detect_stress(text_lower),
            'thought_clarity': self._detect_clarity(text_lower),
            'sleep_quality': self._detect_sleep(text_lower),
            'motivation': self._extract_motivation(text),
            'emotions': self._detect_emotions(text_lower)
        }
        
        return analysis

    def _detect_mood(self, text: str) -> str:
        """Detect primary mood from text"""
        mood_scores = {}
        for mood, keywords in self.mood_patterns.items():
            score = sum(1 for keyword in keywords if keyword in text)
            if score > 0:
                mood_scores[mood] = score
        
        return max(mood_scores.items(), key=lambda x: x[1])[0] if mood_scores else 'neutral'

    def _detect_energy(self, text: str) -> str:
        """Detect energy level from text"""
        for level, keywords in self.energy_patterns.items():
            if any(keyword in text for keyword in keywords):
                return level
        return 'medium'

    def _detect_stress(self, text: str) -> str:
        """Detect stress level from text"""
        for level, keywords in self.stress_patterns.items():
            if any(keyword in text for keyword in keywords):
                return level
        return 'low'

    def _detect_clarity(self, text: str) -> str:
        """Detect thought clarity from text"""
        for level, keywords in self.clarity_patterns.items():
            if any(keyword in text for keyword in keywords):
                return level
        return 'clear'

    def _detect_sleep(self, text: str) -> str:
        """Detect sleep quality mentions"""
        for quality, keywords in self.sleep_patterns.items():
            if any(keyword in text for keyword in keywords):
                return quality
        return 'not mentioned'

    def _extract_motivation(self, text: str) -> str:
        """Extract motivation and intention statements"""
        motivation_patterns = [
            r"I want to (.+?)[\.\,\!]",
            r"I will (.+?)[\.\,\!]", 
            r"I need to (.+?)[\.\,\!]",
            r"I hope to (.+?)[\.\,\!]",
            r"I plan to (.+?)[\.\,\!]"
        ]
        
        motivations = []
        for pattern in motivation_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            motivations.extend(matches)
        
        return '; '.join(motivations) if motivations else 'None detected'

    def _detect_emotions(self, text: str) -> List[str]:
        """Detect multiple emotional tags"""
        detected_emotions = []
        for emotion in self.emotion_tags:
            if emotion in text:
                detected_emotions.append(emotion)
        
        return detected_emotions if detected_emotions else ['neutral']

    def save_to_notion(self, analysis: Dict[str, Any]) -> bool:
        """Save analysis results to Notion database"""
        try:
            # Prepare data for Notion
            notion_data = {
                "Date": {
                    "date": {
                        "start": datetime.now().strftime("%Y-%m-%d")
                    }
                },
                "Mood": {
                    "select": {
                        "name": analysis['mood'].title()
                    }
                },
                "Energy": {
                    "select": {
                        "name": analysis['energy'].title()
                    }
                },
                "Stress": {
                    "select": {
                        "name": analysis['stress'].title()
                    }
                },
                "Thought Clarity": {
                    "select": {
                        "name": analysis['thought_clarity'].title()
                    }
                },
                "Sleep": {
                    "select": {
                        "name": analysis['sleep_quality'].title()
                    }
                },
                "Motivation": {
                    "rich_text": [
                        {
                            "text": {
                                "content": analysis['motivation']
                            }
                        }
                    ]
                },
                "Emotions": {
                    "multi_select": [
                        {"name": emotion.title()} for emotion in analysis['emotions']
                    ]
                }
            }
            
            # Create page in Notion
            response = self.notion.pages.create(
                parent={"database_id": self.database_id},
                properties=notion_data
            )
            
            print(f"✅ Successfully saved to Notion! Page ID: {response['id']}")
            return True
            
        except Exception as e:
            print(f"❌ Error saving to Notion: {str(e)}")
            return False

    def generate_response(self, analysis: Dict[str, Any]) -> str:
        """Generate supportive response based on analysis"""
        mood = analysis['mood']
        energy = analysis['energy'] 
        stress = analysis['stress']
        
        # Base response
        response = "✅ Journal entry analyzed and saved to Notion! "
        
        # Mood-based responses
        if mood in ['sad', 'anxious']:
            response += f"I notice you're feeling {mood}. "
        elif mood == 'happy':
            response += "Great to see you're feeling positive! "
        
        # Energy and stress suggestions
        if energy == 'low' and stress == 'high':
            response += "You seem tired and stressed. Try a 5-minute breathing exercise. 🧘"
        elif energy == 'high' and mood == 'happy':
            response += "Your energy is great! Perfect time for a creative project. ✨"
        elif stress == 'high':
            response += "High stress detected. Consider taking a short walk or listening to calming music. 🌿"
        else:
            response += "Keep up the self-reflection - it's a powerful tool for growth. 💪"
        
        return response

def main():
    """Main function to run the journal analyzer"""
    print("🧠 Nero AI Journal - Neuroscience-powered Mental Health Analysis")
    print("=" * 60)
    
    # Check environment variables
    if not os.getenv("NOTION_TOKEN"):
        print("❌ Error: NOTION_TOKEN not found in environment variables")
        return
    
    if not os.getenv("NOTION_DATABASE_ID"):
        print("❌ Error: NOTION_DATABASE_ID not found in environment variables")
        return
    
    analyzer = JournalAnalyzer()
    
    print("\nEnter your journal entry below (press Enter twice when done):")
    print("-" * 50)
    
    # Get journal entry from user
    lines = []
    while True:
        try:
            line = input()
            if line == "" and lines:  # Empty line and we have content
                break
            lines.append(line)
        except KeyboardInterrupt:
            print("\n\nExiting...")
            return
    
    journal_entry = "\n".join(lines)
    
    if not journal_entry.strip():
        print("❌ No journal entry provided.")
        return
    
    print("\n🔍 Analyzing your journal entry...")
    
    # Analyze the entry
    analysis = analyzer.analyze_text(journal_entry)
    
    # Display results
    print("\n📊 Analysis Results:")
    print("-" * 30)
    print(f"Mood: {analysis['mood'].title()}")
    print(f"Energy Level: {analysis['energy'].title()}")
    print(f"Stress Level: {analysis['stress'].title()}")
    print(f"Thought Clarity: {analysis['thought_clarity'].title()}")
    print(f"Sleep Quality: {analysis['sleep_quality'].title()}")
    print(f"Motivation: {analysis['motivation']}")
    print(f"Emotions: {', '.join([e.title() for e in analysis['emotions']])}")
    
    # Save to Notion
    print(f"\n💾 Saving to Notion database...")
    success = analyzer.save_to_notion(analysis)
    
    if success:
        # Generate and display supportive response
        response = analyzer.generate_response(analysis)
        print(f"\n💙 {response}")
    else:
        print("\n❌ Failed to save to Notion. Please check your credentials and database setup.")
    
    print("\n" + "=" * 60)
    print("Thank you for using Nero AI Journal. Take care of yourself! 💙")

if __name__ == "__main__":
    main()