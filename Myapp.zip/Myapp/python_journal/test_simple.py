#!/usr/bin/env python3
"""
Simple test to check Notion connection and database structure
"""

import os
from notion_client import Client
from dotenv import load_dotenv

load_dotenv()

def test_notion_connection():
    """Test basic Notion API connection"""
    
    print("🔍 Testing Notion API Connection...")
    
    # Check environment variables
    token = os.getenv("NOTION_TOKEN")
    db_id = os.getenv("NOTION_DATABASE_ID")
    
    if not token:
        print("❌ NOTION_TOKEN not found")
        return False
        
    if not db_id:
        print("❌ NOTION_DATABASE_ID not found")
        return False
    
    print(f"✅ Found credentials")
    print(f"   Token: {token[:20]}...")
    print(f"   Database ID: {db_id}")
    
    # Test connection
    try:
        notion = Client(auth=token)
        
        # Test basic connection
        print("\n🔍 Testing basic API access...")
        users = notion.users.list()
        print(f"✅ API connection successful! Found {len(users['results'])} users")
        
        # Test database access
        print(f"\n🔍 Testing database access...")
        db_info = notion.databases.retrieve(database_id=db_id)
        print(f"✅ Database access successful!")
        print(f"   Database name: {db_info.get('title', [{}])[0].get('plain_text', 'Unnamed')}")
        
        # Show database properties
        print(f"\n📊 Database properties:")
        properties = db_info.get('properties', {})
        for prop_name, prop_info in properties.items():
            prop_type = prop_info.get('type', 'unknown')
            print(f"   - {prop_name}: {prop_type}")
        
        # Try a simple query
        print(f"\n🔍 Testing database query...")
        results = notion.databases.query(database_id=db_id, page_size=1)
        print(f"✅ Database query successful! Found {len(results['results'])} existing entries")
        
        return True
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        return False

def create_test_entry():
    """Create a simple test entry"""
    
    print(f"\n🔍 Creating test entry...")
    
    notion = Client(auth=os.getenv("NOTION_TOKEN"))
    db_id = os.getenv("NOTION_DATABASE_ID")
    
    try:
        # Simple test entry
        test_data = {
            "Date": {
                "date": {
                    "start": "2025-01-06"
                }
            }
        }
        
        response = notion.pages.create(
            parent={"database_id": db_id},
            properties=test_data
        )
        
        print(f"✅ Test entry created successfully!")
        print(f"   Page ID: {response['id']}")
        
    except Exception as e:
        print(f"❌ Error creating test entry: {str(e)}")

if __name__ == "__main__":
    print("🧠 Nero AI Journal - Notion Connection Test")
    print("=" * 50)
    
    if test_notion_connection():
        create_test_entry()
    
    print("\n" + "=" * 50)
    print("Test complete!")