#!/usr/bin/env python3
"""
Quick runner for the Nero AI Journal Analyzer
Usage: python run_analyzer.py "Your journal text here"
"""

import sys
import os
from simple_analyzer import SimpleJournalAnalyzer

def main():
    if len(sys.argv) < 2:
        print("Usage: python run_analyzer.py \"Your journal text here\"")
        return
    
    # Check credentials
    if not os.getenv("NOTION_TOKEN") or not os.getenv("NOTION_DATABASE_ID"):
        print("❌ Missing Notion credentials. Set NOTION_TOKEN and NOTION_DATABASE_ID.")
        return
    
    journal_text = " ".join(sys.argv[1:])
    
    print("🧠 Analyzing journal entry...")
    
    analyzer = SimpleJournalAnalyzer()
    analysis = analyzer.analyze_text(journal_text)
    
    print(f"\n📊 Results: {analysis['mood'].title()} mood, {analysis['energy'].title()} energy, {analysis['stress'].title()} stress")
    
    if analyzer.save_to_notion(analysis):
        response = analyzer.generate_response(analysis)
        print(f"\n💙 {response}")

if __name__ == "__main__":
    main()