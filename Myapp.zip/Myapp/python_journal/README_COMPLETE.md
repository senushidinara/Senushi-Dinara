# Nero AI Journal - Complete System Documentation

## System Overview

Your Nero AI Journal now consists of two powerful, integrated components:

### 1. Node.js Chat Application
- **URL**: http://localhost:5000
- **Features**: Real-time AI conversations, therapeutic interface, message history
- **Technology**: React + Express.js + OpenAI API

### 2. Python Analytics Engine
- **Features**: Automatic chat history sync, psychological analysis, Notion integration, visual dashboards
- **Technology**: Python + Notion API + Matplotlib + Pandas

## Complete Workflow

```
User writes in chat → AI responds → Python syncs to Notion → Analytics generated → Insights provided
```

## How to Use Everything

### Step 1: Chat with Nero AI
1. Open http://localhost:5000 in your browser
2. Start typing your thoughts and feelings
3. Nero AI will respond with therapeutic guidance
4. All conversations are automatically saved

### Step 2: Sync & Analyze
```bash
# One-time sync and dashboard generation
cd python_journal
python auto_sync.py

# Continuous monitoring (runs in background)
python auto_sync.py --continuous
```

### Step 3: View Analytics
- Open `latest_dashboard.html` in your browser
- See mood trends, energy patterns, stress levels
- Track progress over time with beautiful charts

## Available Python Scripts

| Script | Purpose | Usage |
|--------|---------|-------|
| `simple_analyzer.py` | Analyze single journal entry | `python simple_analyzer.py` |
| `history_sync.py` | Sync chat history to Notion | `python history_sync.py` |
| `analytics_dashboard.py` | Generate analytics dashboard | `python analytics_dashboard.py` |
| `auto_sync.py` | Automated sync + analytics | `python auto_sync.py` |
| `demo_conversations.py` | Create test conversations | `python demo_conversations.py` |

## Quick Commands

```bash
# Analyze a single entry
python run_analyzer.py "I feel happy and motivated today!"

# Create demo data for testing
python demo_conversations.py

# Generate full analytics dashboard
python analytics_dashboard.py

# Run continuous sync (background service)
python auto_sync.py --continuous
```

## What Gets Tracked

### Psychological Metrics
- **Mood**: Happy, Sad, Anxious, Angry, Calm, Confused, Neutral
- **Energy Level**: Low, Medium, High
- **Stress Level**: Low, Medium, High
- **Thought Clarity**: Clear, Foggy, Cloudy
- **Emotions**: Multi-tag system (grateful, hopeful, confident, etc.)
- **Motivation**: Extracted goal statements ("I want to...", "I will...")
- **Sleep Quality**: Good, Poor, Okay (when mentioned)

### Analytics Generated
- **Mood trends over time** (line charts)
- **Mood distribution** (pie charts)
- **Energy vs Stress heatmaps**
- **Weekly mood patterns**
- **Recent trend analysis**
- **Key insights and recommendations**

## Data Flow

1. **User Input** → Chat interface
2. **AI Response** → OpenAI GPT-4o
3. **Storage** → In-memory database (development)
4. **Sync** → Python fetches chat history via API
5. **Analysis** → Pattern matching for psychological markers
6. **Storage** → Notion database with structured data
7. **Visualization** → Charts and dashboards
8. **Insights** → Automated recommendations

## System Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   React UI      │    │   Express API    │    │  Python Engine  │
│   (Frontend)    │◄──►│   (Backend)      │◄──►│  (Analytics)    │
└─────────────────┘    └──────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│  Browser Chat   │    │  In-Memory DB    │    │  Notion API     │
│   Interface     │    │  (Dev Storage)   │    │  (Analytics)    │
└─────────────────┘    └──────────────────┘    └─────────────────┘
```

## Benefits of This System

### For Users
- **Immediate Support**: Real-time AI therapeutic conversations
- **Long-term Insights**: Track mental health patterns over time
- **Visual Progress**: Beautiful charts showing mood trends
- **Goal Tracking**: Automatic extraction of intentions and goals
- **Privacy**: All data stored securely in your personal Notion

### For Development
- **Scalable**: Easy to add new psychological markers
- **Flexible**: Works with any Notion database structure
- **Automated**: Background sync requires no manual intervention
- **Extensible**: Can add new chart types and analytics

## Next Steps

1. **Use the chat interface** regularly for best data
2. **Run analytics weekly** to see meaningful trends
3. **Customize Notion database** with additional columns
4. **Set up continuous sync** for real-time analytics
5. **Share insights** with healthcare providers if desired

## Troubleshooting

### Common Issues
- **No data in dashboard**: Run `python demo_conversations.py` first
- **Notion sync fails**: Check NOTION_TOKEN and NOTION_DATABASE_ID
- **Charts not generating**: Ensure matplotlib dependencies installed
- **API connection fails**: Verify Node.js app is running on port 5000

### Support Commands
```bash
# Test Notion connection
python test_simple.py

# Check available data
python -c "from analytics_dashboard import JournalAnalytics; a = JournalAnalytics(); print(len(a.fetch_all_entries()), 'entries found')"

# Verify API connectivity
curl http://localhost:5000/api/conversations
```

This is your complete mental health journaling system - chat with Nero AI and automatically get psychological insights saved to Notion with beautiful analytics!