#!/usr/bin/env python3
"""
Setup script to create the Notion database for Nero AI Journal
"""

import os
from notion_client import Client
from dotenv import load_dotenv

load_dotenv()

def create_journal_database():
    """Create a new Notion database with the required structure"""
    notion = Client(auth=os.getenv("NOTION_TOKEN"))
    
    # Database properties schema
    properties = {
        "Date": {
            "date": {}
        },
        "Mood": {
            "select": {
                "options": [
                    {"name": "Happy", "color": "green"},
                    {"name": "Sad", "color": "blue"}, 
                    {"name": "Anxious", "color": "yellow"},
                    {"name": "Angry", "color": "red"},
                    {"name": "Calm", "color": "purple"},
                    {"name": "Confused", "color": "gray"},
                    {"name": "Neutral", "color": "default"}
                ]
            }
        },
        "Energy": {
            "select": {
                "options": [
                    {"name": "Low", "color": "red"},
                    {"name": "Medium", "color": "yellow"},
                    {"name": "High", "color": "green"}
                ]
            }
        },
        "Stress": {
            "select": {
                "options": [
                    {"name": "Low", "color": "green"},
                    {"name": "Medium", "color": "yellow"},
                    {"name": "High", "color": "red"}
                ]
            }
        },
        "Thought Clarity": {
            "select": {
                "options": [
                    {"name": "Clear", "color": "green"},
                    {"name": "Foggy", "color": "yellow"},
                    {"name": "Cloudy", "color": "gray"}
                ]
            }
        },
        "Sleep": {
            "select": {
                "options": [
                    {"name": "Good", "color": "green"},
                    {"name": "Poor", "color": "red"},
                    {"name": "Okay", "color": "yellow"},
                    {"name": "Not Mentioned", "color": "gray"}
                ]
            }
        },
        "Motivation": {
            "rich_text": {}
        },
        "Emotions": {
            "multi_select": {
                "options": [
                    {"name": "Grateful", "color": "green"},
                    {"name": "Hopeful", "color": "blue"},
                    {"name": "Proud", "color": "purple"},
                    {"name": "Lonely", "color": "gray"},
                    {"name": "Guilty", "color": "red"},
                    {"name": "Ashamed", "color": "red"},
                    {"name": "Confident", "color": "green"},
                    {"name": "Insecure", "color": "yellow"},
                    {"name": "Loved", "color": "pink"},
                    {"name": "Rejected", "color": "red"},
                    {"name": "Optimistic", "color": "blue"},
                    {"name": "Pessimistic", "color": "gray"},
                    {"name": "Creative", "color": "purple"},
                    {"name": "Stuck", "color": "orange"},
                    {"name": "Determined", "color": "green"},
                    {"name": "Defeated", "color": "red"},
                    {"name": "Neutral", "color": "default"}
                ]
            }
        }
    }
    
    try:
        # Create the database
        response = notion.databases.create(
            parent={
                "type": "page_id",
                "page_id": "your_page_id_here"  # You'll need to replace this
            },
            title=[
                {
                    "type": "text",
                    "text": {
                        "content": "Nero AI Journal Database"
                    }
                }
            ],
            properties=properties
        )
        
        print("✅ Database created successfully!")
        print(f"Database ID: {response['id']}")
        print("Add this ID to your NOTION_DATABASE_ID environment variable")
        
    except Exception as e:
        print(f"❌ Error creating database: {str(e)}")
        print("\nTo create the database manually:")
        print("1. Create a new database in Notion")
        print("2. Add the columns listed in README.md") 
        print("3. Share the database with your integration")
        print("4. Copy the database ID from the URL")

if __name__ == "__main__":
    create_journal_database()