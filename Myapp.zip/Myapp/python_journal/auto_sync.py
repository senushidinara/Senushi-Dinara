#!/usr/bin/env python3
"""
Automatic synchronization service for Nero AI Journal
Runs in background to sync chat history and generate analytics
"""

import time
import schedule
import os
from datetime import datetime
from history_sync import ChatHistorySync
from analytics_dashboard import JournalAnalytics

class AutoSyncService:
    def __init__(self):
        self.sync = ChatHistorySync()
        self.analytics = JournalAnalytics()
        self.last_sync = None
        
    def run_sync_job(self):
        """Run synchronization job"""
        print(f"\n🔄 Auto-sync started at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        try:
            # Sync conversations
            results = self.sync.sync_all_conversations()
            self.last_sync = datetime.now()
            
            print(f"✅ Sync completed: {results['synced']} conversations synced")
            
            # Generate dashboard if we have data
            if results['synced'] > 0:
                self.generate_dashboard()
                
        except Exception as e:
            print(f"❌ Sync failed: {str(e)}")
    
    def generate_dashboard(self):
        """Generate analytics dashboard"""
        try:
            print("📊 Generating analytics dashboard...")
            
            # Fetch and process data
            entries = self.analytics.fetch_all_entries()
            if not entries:
                print("⚠️  No entries found for dashboard")
                return
            
            df = self.analytics.parse_entry_data(entries)
            
            # Generate charts
            mood_chart = self.analytics.generate_mood_trend_chart(df)
            distribution_chart = self.analytics.generate_mood_distribution_chart(df)
            heatmap_chart = self.analytics.generate_energy_stress_heatmap(df)
            
            # Generate insights
            insights = self.analytics.generate_insights_report(df)
            
            # Create dashboard
            dashboard_html = self.analytics.create_html_dashboard(
                df, mood_chart, distribution_chart, heatmap_chart, insights
            )
            
            # Save with timestamp
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            dashboard_path = f"dashboard_{timestamp}.html"
            
            with open(dashboard_path, 'w') as f:
                f.write(dashboard_html)
            
            # Also save as latest
            with open('latest_dashboard.html', 'w') as f:
                f.write(dashboard_html)
            
            print(f"✅ Dashboard generated: {dashboard_path}")
            print(f"📊 Analytics summary: {insights.get('total_entries', 0)} entries, {insights.get('most_common_mood', 'N/A')} mood")
            
        except Exception as e:
            print(f"❌ Dashboard generation failed: {str(e)}")
    
    def run_continuous(self):
        """Run continuous monitoring"""
        print("🚀 Starting Nero AI Auto-Sync Service")
        print("=" * 50)
        print("Schedule:")
        print("  - Chat sync: Every 5 minutes")
        print("  - Analytics update: Every 15 minutes")
        print("  - Dashboard refresh: Every hour")
        print("=" * 50)
        
        # Schedule jobs
        schedule.every(5).minutes.do(self.run_sync_job)
        schedule.every(15).minutes.do(self.generate_dashboard)
        
        # Run initial sync
        self.run_sync_job()
        
        # Keep running
        while True:
            schedule.run_pending()
            time.sleep(60)  # Check every minute

def main():
    """Main entry point"""
    if not os.getenv("NOTION_TOKEN") or not os.getenv("NOTION_DATABASE_ID"):
        print("❌ Missing Notion credentials")
        return
    
    service = AutoSyncService()
    
    # Check if running in continuous mode
    import sys
    if '--continuous' in sys.argv:
        service.run_continuous()
    else:
        # One-time sync and dashboard generation
        print("🔄 Running one-time sync and analytics generation...")
        service.run_sync_job()

if __name__ == "__main__":
    main()