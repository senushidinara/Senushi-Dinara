#!/usr/bin/env python3
"""
Simplified Nero AI Journal Analyzer - Works with any Notion database
"""

import os
import re
import json
from datetime import datetime
from typing import Dict, List, Any
from notion_client import Client

class SimpleJournalAnalyzer:
    def __init__(self):
        # Initialize Notion client
        self.notion = Client(auth=os.getenv("NOTION_TOKEN"))
        self.database_id = os.getenv("NOTION_DATABASE_ID")
        
        # Analysis patterns (same as before)
        self.mood_patterns = {
            'happy': ['happy', 'joy', 'excited', 'cheerful', 'elated', 'content', 'pleased'],
            'sad': ['sad', 'depressed', 'down', 'blue', 'melancholy', 'grief', 'sorrow'],
            'anxious': ['anxious', 'worried', 'nervous', 'stressed', 'panic', 'fear', 'overwhelmed'],
            'angry': ['angry', 'mad', 'furious', 'irritated', 'frustrated', 'rage'],
            'calm': ['calm', 'peaceful', 'serene', 'relaxed', 'tranquil'],
            'confused': ['confused', 'lost', 'unclear', 'puzzled', 'bewildered']
        }
        
        self.energy_patterns = {
            'high': ['energetic', 'motivated', 'pumped', 'active', 'vibrant', 'dynamic'],
            'medium': ['okay', 'decent', 'moderate', 'balanced', 'stable'],
            'low': ['tired', 'exhausted', 'drained', 'fatigued', 'sluggish', 'weary']
        }
        
        self.stress_patterns = {
            'high': ['overwhelmed', 'stressed', 'pressure', 'burden', 'intense', 'chaotic'],
            'medium': ['busy', 'challenged', 'stretched', 'demanding'],
            'low': ['relaxed', 'easy', 'manageable', 'comfortable', 'peaceful']
        }

    def analyze_text(self, text: str) -> Dict[str, Any]:
        """Analyze journal entry text"""
        text_lower = text.lower()
        
        # Extract key insights
        mood = self._detect_mood(text_lower)
        energy = self._detect_energy(text_lower)
        stress = self._detect_stress(text_lower)
        emotions = self._detect_emotions(text_lower)
        motivation = self._extract_motivation(text)
        
        # Create summary
        summary = f"Mood: {mood.title()} | Energy: {energy.title()} | Stress: {stress.title()}"
        if emotions:
            summary += f" | Emotions: {', '.join(emotions).title()}"
        if motivation != "None detected":
            summary += f" | Goals: {motivation}"
        
        analysis = {
            'original_text': text,
            'date': datetime.now().isoformat(),
            'mood': mood,
            'energy': energy,
            'stress': stress,
            'emotions': emotions,
            'motivation': motivation,
            'summary': summary
        }
        
        return analysis

    def _detect_mood(self, text: str) -> str:
        """Detect primary mood from text"""
        mood_scores = {}
        for mood, keywords in self.mood_patterns.items():
            score = sum(1 for keyword in keywords if keyword in text)
            if score > 0:
                mood_scores[mood] = score
        
        return max(mood_scores.items(), key=lambda x: x[1])[0] if mood_scores else 'neutral'

    def _detect_energy(self, text: str) -> str:
        """Detect energy level from text"""
        for level, keywords in self.energy_patterns.items():
            if any(keyword in text for keyword in keywords):
                return level
        return 'medium'

    def _detect_stress(self, text: str) -> str:
        """Detect stress level from text"""
        for level, keywords in self.stress_patterns.items():
            if any(keyword in text for keyword in keywords):
                return level
        return 'low'

    def _detect_emotions(self, text: str) -> List[str]:
        """Detect emotional keywords"""
        emotions = ['grateful', 'hopeful', 'proud', 'lonely', 'guilty', 'confident', 
                   'insecure', 'loved', 'rejected', 'optimistic', 'creative', 'determined']
        
        detected = [emotion for emotion in emotions if emotion in text]
        return detected if detected else ['neutral']

    def _extract_motivation(self, text: str) -> str:
        """Extract motivation statements"""
        patterns = [
            r"I want to (.+?)[\.\,\!]",
            r"I will (.+?)[\.\,\!]", 
            r"I need to (.+?)[\.\,\!]",
            r"I hope to (.+?)[\.\,\!]"
        ]
        
        motivations = []
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            motivations.extend(matches)
        
        return '; '.join(motivations) if motivations else 'None detected'

    def save_to_notion(self, analysis: Dict[str, Any]) -> bool:
        """Save analysis to Notion database with simple title format"""
        try:
            # Get current database structure
            db_info = self.notion.databases.retrieve(database_id=self.database_id)
            properties = db_info.get('properties', {})
            
            # Create entry title with analysis summary
            title = f"Journal Entry - {datetime.now().strftime('%Y-%m-%d %H:%M')} - {analysis['summary']}"
            
            # Prepare data based on available properties
            notion_data = {}
            
            # Always add title if Name property exists
            if 'Name' in properties:
                notion_data['Name'] = {
                    "title": [
                        {
                            "text": {
                                "content": title
                            }
                        }
                    ]
                }
            
            # Add other properties if they exist
            if 'Date' in properties:
                notion_data['Date'] = {
                    "date": {
                        "start": datetime.now().strftime("%Y-%m-%d")
                    }
                }
            
            if 'Content' in properties:
                notion_data['Content'] = {
                    "rich_text": [
                        {
                            "text": {
                                "content": analysis['original_text']
                            }
                        }
                    ]
                }
            
            if 'Analysis' in properties:
                analysis_text = f"""
Mood: {analysis['mood'].title()}
Energy: {analysis['energy'].title()}
Stress: {analysis['stress'].title()}
Emotions: {', '.join(analysis['emotions']).title()}
Motivation: {analysis['motivation']}
"""
                notion_data['Analysis'] = {
                    "rich_text": [
                        {
                            "text": {
                                "content": analysis_text.strip()
                            }
                        }
                    ]
                }
            
            # Create page in Notion
            response = self.notion.pages.create(
                parent={"database_id": self.database_id},
                properties=notion_data
            )
            
            print(f"✅ Successfully saved to Notion!")
            print(f"   Page ID: {response['id']}")
            print(f"   Title: {title}")
            return True
            
        except Exception as e:
            print(f"❌ Error saving to Notion: {str(e)}")
            return False

    def generate_response(self, analysis: Dict[str, Any]) -> str:
        """Generate supportive response"""
        mood = analysis['mood']
        energy = analysis['energy'] 
        stress = analysis['stress']
        
        response = "✅ Journal entry analyzed and saved to Notion! "
        
        # Personalized responses
        if mood == 'anxious' and stress == 'high':
            response += "I notice you're feeling anxious and stressed. Try some deep breathing or a short walk. 🌿"
        elif mood == 'sad':
            response += "I hear that you're feeling down. Remember that it's okay to feel this way, and it will pass. 💙"
        elif mood == 'happy':
            response += "Wonderful to see you feeling positive! This energy can fuel great things. ✨"
        elif energy == 'low':
            response += "You seem tired. Make sure to rest and be gentle with yourself. 😌"
        else:
            response += "Thank you for sharing your thoughts. Self-reflection is a powerful tool for growth. 💪"
        
        return response

def main():
    """Main function"""
    print("🧠 Nero AI Journal - Simple Analyzer")
    print("=" * 50)
    
    # Check credentials
    if not os.getenv("NOTION_TOKEN") or not os.getenv("NOTION_DATABASE_ID"):
        print("❌ Missing Notion credentials. Check NOTION_TOKEN and NOTION_DATABASE_ID.")
        return
    
    analyzer = SimpleJournalAnalyzer()
    
    print("\nEnter your journal entry (press Enter twice when done):")
    print("-" * 40)
    
    # Get input
    lines = []
    try:
        while True:
            line = input()
            if line == "" and lines:
                break
            lines.append(line)
    except KeyboardInterrupt:
        print("\nExiting...")
        return
    
    journal_entry = "\n".join(lines)
    
    if not journal_entry.strip():
        print("❌ No journal entry provided.")
        return
    
    print(f"\n🔍 Analyzing entry...")
    
    # Analyze
    analysis = analyzer.analyze_text(journal_entry)
    
    # Display results
    print(f"\n📊 Analysis Results:")
    print(f"   Mood: {analysis['mood'].title()}")
    print(f"   Energy: {analysis['energy'].title()}")
    print(f"   Stress: {analysis['stress'].title()}")
    print(f"   Emotions: {', '.join(analysis['emotions']).title()}")
    print(f"   Motivation: {analysis['motivation']}")
    
    # Save to Notion
    print(f"\n💾 Saving to Notion...")
    success = analyzer.save_to_notion(analysis)
    
    if success:
        response = analyzer.generate_response(analysis)
        print(f"\n💙 {response}")
    
    print(f"\n{'='*50}")

if __name__ == "__main__":
    main()