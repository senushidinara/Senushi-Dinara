# Nero AI Journal - Python Analytics Module

This Python module provides advanced neuroscience-powered analysis of journal entries and automatically saves structured data to Notion.

## Features

🧠 **Advanced Text Analysis:**
- Mood detection (happy, sad, anxious, angry, calm, confused)
- Energy level assessment (low, medium, high)
- Stress level identification (low, medium, high)
- Thought clarity evaluation (clear, foggy, cloudy)
- Sleep quality mentions
- Motivation extraction (I want to..., I will...)
- Multi-emotion tagging

📊 **Notion Database Integration:**
- Automatic structured data entry
- Date tracking
- Multi-select emotion tags
- Rich text motivation capture

## Setup Instructions

### 1. Notion Database Setup

Create a new database in Notion with these exact column names and types:

| Column Name | Type | Options |
|-------------|------|---------|
| Date | Date | - |
| Mood | Select | Happy, Sad, Anxious, Angry, Calm, Confused, Neutral |
| Energy | Select | Low, Medium, High |
| Stress | Select | Low, Medium, High |
| Thought Clarity | Select | Clear, Foggy, Cloudy |
| Sleep | Select | Good, Poor, Okay, Not Mentioned |
| Motivation | Rich Text | - |
| Emotions | Multi-select | Grateful, Hopeful, Proud, Lonely, Guilty, Ashamed, Confident, Insecure, Loved, Rejected, Optimistic, Pessimistic, Creative, Stuck, Determined, Defeated, Neutral |

### 2. Notion Integration Setup

1. Go to [Notion Developers](https://developers.notion.com/)
2. Click "Create new integration"
3. Give it a name like "Nero AI Journal"
4. Copy the "Internal Integration Token"
5. Go to your database in Notion
6. Click "Share" → "Add people" → Select your integration

### 3. Environment Variables

1. Copy `.env.example` to `.env`
2. Add your Notion token and database ID:

```bash
NOTION_TOKEN=secret_your_token_here
NOTION_DATABASE_ID=your_database_id_from_url
```

### 4. Run the Analyzer

```bash
python python_journal/main.py
```

## Usage Example

```
🧠 Nero AI Journal - Neuroscience-powered Mental Health Analysis
============================================================

Enter your journal entry below (press Enter twice when done):
--------------------------------------------------
I feel tired and overwhelmed, but hopeful about my project. 
I want to finish my coding work by Friday.

🔍 Analyzing your journal entry...

📊 Analysis Results:
------------------------------
Mood: Anxious
Energy Level: Low
Stress Level: High
Thought Clarity: Clear
Sleep Quality: Not Mentioned
Motivation: finish my coding work by Friday
Emotions: Hopeful

💾 Saving to Notion database...
✅ Successfully saved to Notion! Page ID: 12345...

💙 ✅ Journal entry analyzed and saved to Notion! I notice you're feeling anxious. You seem tired and stressed. Try a 5-minute breathing exercise. 🧘

============================================================
Thank you for using Nero AI Journal. Take care of yourself! 💙
```

## Integration with Main App

This Python module works alongside your main Node.js Nero AI chat application:

- **Node.js App**: Beautiful chat interface with real-time AI conversations
- **Python Module**: Deep psychological analysis and Notion database logging

Use both together for a complete mental health journaling experience!