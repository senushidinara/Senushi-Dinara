#!/usr/bin/env python3
"""
Nero AI Journal - Analytics Dashboard
Generate charts and insights from Notion journal data
"""

import os
import json
from datetime import datetime, timedelta
from collections import Counter, defaultdict
from typing import Dict, List, Any
from notion_client import Client
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
from io import BytesIO
import base64

class JournalAnalytics:
    def __init__(self):
        self.notion = Client(auth=os.getenv("NOTION_TOKEN"))
        self.database_id = os.getenv("NOTION_DATABASE_ID")
        
    def fetch_all_entries(self) -> List[Dict]:
        """Fetch all journal entries from Notion"""
        try:
            entries = []
            has_more = True
            start_cursor = None
            
            while has_more:
                query_params = {
                    "database_id": self.database_id,
                    "page_size": 100
                }
                if start_cursor:
                    query_params["start_cursor"] = start_cursor
                
                response = self.notion.databases.query(**query_params)
                entries.extend(response["results"])
                
                has_more = response["has_more"]
                start_cursor = response.get("next_cursor")
            
            return entries
        except Exception as e:
            print(f"Error fetching entries: {str(e)}")
            return []
    
    def parse_entry_data(self, entries: List[Dict]) -> pd.DataFrame:
        """Parse Notion entries into structured data"""
        data = []
        
        for entry in entries:
            properties = entry.get("properties", {})
            
            # Extract basic info
            title = ""
            if "Name" in properties and properties["Name"]["title"]:
                title = properties["Name"]["title"][0]["plain_text"]
            
            # Extract date
            date = None
            if "Date" in properties and properties["Date"]["date"]:
                date = properties["Date"]["date"]["start"]
            else:
                # Fallback to creation date
                date = entry["created_time"][:10]
            
            # Parse analysis from title or content
            mood, energy, stress, emotions = self._extract_analysis_from_title(title)
            
            data.append({
                'date': date,
                'title': title,
                'mood': mood,
                'energy': energy,
                'stress': stress,
                'emotions': emotions,
                'created_time': entry["created_time"]
            })
        
        return pd.DataFrame(data)
    
    def _extract_analysis_from_title(self, title: str) -> tuple:
        """Extract mood, energy, stress from title"""
        title_lower = title.lower()
        
        # Extract mood
        moods = ['happy', 'sad', 'anxious', 'angry', 'calm', 'confused', 'neutral']
        mood = 'neutral'
        for m in moods:
            if m in title_lower:
                mood = m
                break
        
        # Extract energy
        energy = 'medium'
        if 'high' in title_lower and 'energy' in title_lower:
            energy = 'high'
        elif 'low' in title_lower and 'energy' in title_lower:
            energy = 'low'
        
        # Extract stress
        stress = 'low'
        if 'high' in title_lower and 'stress' in title_lower:
            stress = 'high'
        elif 'medium' in title_lower and 'stress' in title_lower:
            stress = 'medium'
        
        # Extract emotions
        emotion_keywords = ['hopeful', 'grateful', 'proud', 'confident', 'creative', 'determined']
        emotions = [e for e in emotion_keywords if e in title_lower]
        
        return mood, energy, stress, emotions
    
    def generate_mood_trend_chart(self, df: pd.DataFrame) -> str:
        """Generate mood trend chart"""
        if df.empty:
            return ""
        
        plt.figure(figsize=(12, 6))
        df['date'] = pd.to_datetime(df['date'])
        df_sorted = df.sort_values('date')
        
        # Map moods to numeric values for trending
        mood_values = {
            'happy': 5, 'calm': 4, 'neutral': 3, 'confused': 2, 
            'anxious': 1, 'sad': 1, 'angry': 1
        }
        df_sorted['mood_score'] = df_sorted['mood'].map(mood_values)
        
        plt.plot(df_sorted['date'], df_sorted['mood_score'], marker='o', linewidth=2, markersize=6)
        plt.title('Mood Trend Over Time', fontsize=16, fontweight='bold')
        plt.xlabel('Date')
        plt.ylabel('Mood Score (1=Low, 5=High)')
        plt.grid(True, alpha=0.3)
        plt.xticks(rotation=45)
        plt.tight_layout()
        
        # Save to base64
        buffer = BytesIO()
        plt.savefig(buffer, format='png', dpi=150, bbox_inches='tight')
        buffer.seek(0)
        image_base64 = base64.b64encode(buffer.getvalue()).decode()
        plt.close()
        
        return image_base64
    
    def generate_mood_distribution_chart(self, df: pd.DataFrame) -> str:
        """Generate mood distribution pie chart"""
        if df.empty:
            return ""
        
        mood_counts = df['mood'].value_counts()
        
        plt.figure(figsize=(10, 8))
        colors = plt.cm.Set3(range(len(mood_counts)))
        plt.pie(mood_counts.values, labels=mood_counts.index, autopct='%1.1f%%', 
                colors=colors, startangle=90)
        plt.title('Mood Distribution', fontsize=16, fontweight='bold')
        
        buffer = BytesIO()
        plt.savefig(buffer, format='png', dpi=150, bbox_inches='tight')
        buffer.seek(0)
        image_base64 = base64.b64encode(buffer.getvalue()).decode()
        plt.close()
        
        return image_base64
    
    def generate_energy_stress_heatmap(self, df: pd.DataFrame) -> str:
        """Generate energy vs stress heatmap"""
        if df.empty:
            return ""
        
        # Create energy-stress matrix
        energy_stress = df.groupby(['energy', 'stress']).size().unstack(fill_value=0)
        
        plt.figure(figsize=(8, 6))
        sns.heatmap(energy_stress, annot=True, cmap='YlOrRd', fmt='d')
        plt.title('Energy vs Stress Levels', fontsize=16, fontweight='bold')
        plt.xlabel('Stress Level')
        plt.ylabel('Energy Level')
        
        buffer = BytesIO()
        plt.savefig(buffer, format='png', dpi=150, bbox_inches='tight')
        buffer.seek(0)
        image_base64 = base64.b64encode(buffer.getvalue()).decode()
        plt.close()
        
        return image_base64
    
    def generate_insights_report(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Generate detailed insights report"""
        if df.empty:
            return {}
        
        insights = {}
        
        # Basic stats
        insights['total_entries'] = len(df)
        insights['date_range'] = {
            'start': df['date'].min(),
            'end': df['date'].max()
        }
        
        # Mood analysis
        mood_counts = df['mood'].value_counts()
        insights['most_common_mood'] = mood_counts.index[0] if not mood_counts.empty else 'neutral'
        insights['mood_distribution'] = mood_counts.to_dict()
        
        # Energy patterns
        energy_counts = df['energy'].value_counts()
        insights['energy_distribution'] = energy_counts.to_dict()
        
        # Stress patterns
        stress_counts = df['stress'].value_counts()
        insights['stress_distribution'] = stress_counts.to_dict()
        
        # Weekly patterns
        df['date'] = pd.to_datetime(df['date'])
        df['day_of_week'] = df['date'].dt.day_name()
        day_mood = df.groupby('day_of_week')['mood'].apply(lambda x: x.mode().iloc[0] if not x.empty else 'neutral')
        insights['weekly_mood_pattern'] = day_mood.to_dict()
        
        # Recent trends (last 7 days)
        recent_date = df['date'].max() - timedelta(days=7)
        recent_entries = df[df['date'] > recent_date]
        if not recent_entries.empty:
            insights['recent_trend'] = {
                'dominant_mood': recent_entries['mood'].mode().iloc[0] if not recent_entries['mood'].empty else 'neutral',
                'avg_energy': recent_entries['energy'].mode().iloc[0] if not recent_entries['energy'].empty else 'medium',
                'avg_stress': recent_entries['stress'].mode().iloc[0] if not recent_entries['stress'].empty else 'low'
            }
        
        return insights
    
    def create_html_dashboard(self, df: pd.DataFrame, mood_chart: str, distribution_chart: str, 
                            heatmap_chart: str, insights: Dict) -> str:
        """Create HTML dashboard"""
        html_template = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Nero AI Journal - Analytics Dashboard</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        .header {{ text-align: center; color: #2c3e50; margin-bottom: 30px; }}
        .stats-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px; }}
        .stat-card {{ background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
        .stat-card h3 {{ margin: 0 0 10px 0; color: #34495e; }}
        .chart-container {{ background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 20px; }}
        .chart-container h2 {{ color: #2c3e50; margin-top: 0; }}
        .insights {{ background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
        .insight-item {{ margin: 10px 0; }}
        .positive {{ color: #27ae60; }}
        .neutral {{ color: #f39c12; }}
        .negative {{ color: #e74c3c; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🧠 Nero AI Journal Analytics Dashboard</h1>
            <p>Comprehensive analysis of your mental health journey</p>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>📊 Total Entries</h3>
                <p style="font-size: 2em; margin: 0;">{insights.get('total_entries', 0)}</p>
            </div>
            <div class="stat-card">
                <h3>😊 Most Common Mood</h3>
                <p style="font-size: 1.5em; margin: 0;">{insights.get('most_common_mood', 'N/A').title()}</p>
            </div>
            <div class="stat-card">
                <h3>📅 Tracking Period</h3>
                <p>{insights.get('date_range', {}).get('start', 'N/A')} to {insights.get('date_range', {}).get('end', 'N/A')}</p>
            </div>
            <div class="stat-card">
                <h3>🎯 Recent Trend</h3>
                <p>{insights.get('recent_trend', {}).get('dominant_mood', 'N/A').title()} mood lately</p>
            </div>
        </div>
        
        <div class="chart-container">
            <h2>📈 Mood Trend Over Time</h2>
            <img src="data:image/png;base64,{mood_chart}" style="max-width: 100%; height: auto;">
        </div>
        
        <div class="chart-container">
            <h2>🥧 Mood Distribution</h2>
            <img src="data:image/png;base64,{distribution_chart}" style="max-width: 100%; height: auto;">
        </div>
        
        <div class="chart-container">
            <h2>🔥 Energy vs Stress Heatmap</h2>
            <img src="data:image/png;base64,{heatmap_chart}" style="max-width: 100%; height: auto;">
        </div>
        
        <div class="insights">
            <h2>💡 Key Insights</h2>
            <div class="insight-item">
                <strong>Weekly Pattern:</strong> You tend to feel most positive on: {max(insights.get('weekly_mood_pattern', {}), key=insights.get('weekly_mood_pattern', {}).get, default='N/A')}
            </div>
            <div class="insight-item">
                <strong>Energy Distribution:</strong> {', '.join([f"{k}: {v}" for k, v in insights.get('energy_distribution', {}).items()])}
            </div>
            <div class="insight-item">
                <strong>Stress Levels:</strong> {', '.join([f"{k}: {v}" for k, v in insights.get('stress_distribution', {}).items()])}
            </div>
        </div>
    </div>
</body>
</html>
"""
        return html_template

def main():
    """Generate analytics dashboard"""
    print("📊 Generating Nero AI Journal Analytics Dashboard...")
    
    if not os.getenv("NOTION_TOKEN") or not os.getenv("NOTION_DATABASE_ID"):
        print("❌ Missing Notion credentials")
        return
    
    analytics = JournalAnalytics()
    
    # Fetch and process data
    print("📥 Fetching data from Notion...")
    entries = analytics.fetch_all_entries()
    
    if not entries:
        print("❌ No entries found in Notion database")
        return
    
    print(f"✅ Found {len(entries)} entries")
    
    # Parse data
    df = analytics.parse_entry_data(entries)
    print(f"📊 Processed {len(df)} entries for analysis")
    
    # Generate charts
    print("📈 Generating charts...")
    mood_chart = analytics.generate_mood_trend_chart(df)
    distribution_chart = analytics.generate_mood_distribution_chart(df)
    heatmap_chart = analytics.generate_energy_stress_heatmap(df)
    
    # Generate insights
    print("💡 Generating insights...")
    insights = analytics.generate_insights_report(df)
    
    # Create dashboard
    print("🎨 Creating HTML dashboard...")
    dashboard_html = analytics.create_html_dashboard(df, mood_chart, distribution_chart, heatmap_chart, insights)
    
    # Save dashboard
    dashboard_path = "analytics_dashboard.html"
    with open(dashboard_path, 'w') as f:
        f.write(dashboard_html)
    
    print(f"✅ Dashboard saved to {dashboard_path}")
    print(f"💡 Open the file in your browser to view your analytics!")
    
    # Print summary
    print(f"\n📊 Summary:")
    print(f"   Total entries: {insights.get('total_entries', 0)}")
    print(f"   Most common mood: {insights.get('most_common_mood', 'N/A').title()}")
    print(f"   Recent trend: {insights.get('recent_trend', {}).get('dominant_mood', 'N/A').title()}")

if __name__ == "__main__":
    main()