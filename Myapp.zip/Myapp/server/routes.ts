import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { openAIService } from "./services/openai";
import { insertMessageSchema, insertConversationSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Create a new conversation
  app.post("/api/conversations", async (req, res) => {
    try {
      const validatedData = insertConversationSchema.parse(req.body);
      const conversation = await storage.createConversation(validatedData);
      res.json(conversation);
    } catch (error) {
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Failed to create conversation" 
      });
    }
  });

  // Get user conversations
  app.get("/api/conversations", async (req, res) => {
    try {
      const userId = req.query.userId as string || "default_user";
      const conversations = await storage.getUserConversations(userId);
      res.json(conversations);
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to fetch conversations" 
      });
    }
  });

  // Get conversation messages
  app.get("/api/conversations/:id/messages", async (req, res) => {
    try {
      const { id } = req.params;
      const conversation = await storage.getConversation(id);
      
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }

      const messages = await storage.getConversationMessages(id);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to fetch messages" 
      });
    }
  });

  // Send a message and get AI response
  app.post("/api/conversations/:id/messages", async (req, res) => {
    try {
      const { id } = req.params;
      const conversation = await storage.getConversation(id);
      
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }

      // Validate and create user message
      const messageData = insertMessageSchema.parse({
        ...req.body,
        conversationId: id,
        role: "user"
      });

      const userMessage = await storage.createMessage(messageData);

      // Get conversation history for AI context
      const previousMessages = await storage.getConversationMessages(id);
      const conversationHistory = previousMessages.map(msg => ({
        role: msg.role as "user" | "assistant",
        content: msg.content
      }));

      // Generate AI response
      try {
        const aiResponseContent = await openAIService.generateResponse(conversationHistory);
        
        // Save AI response
        const aiMessage = await storage.createMessage({
          conversationId: id,
          role: "assistant",
          content: aiResponseContent,
          metadata: null
        });

        res.json({
          userMessage,
          aiMessage
        });
      } catch (aiError) {
        console.error("AI Response Error:", aiError);
        
        // Fallback response if AI fails
        const fallbackResponse = "I'm having trouble connecting right now, but I'm here to listen. Could you tell me more about what you're experiencing? Sometimes talking through things can help even when I can't respond perfectly.";
        
        const aiMessage = await storage.createMessage({
          conversationId: id,
          role: "assistant",
          content: fallbackResponse,
          metadata: { error: true, fallback: true }
        });

        res.json({
          userMessage,
          aiMessage,
          warning: "AI service temporarily unavailable, using fallback response"
        });
      }
    } catch (error) {
      console.error("Message creation error:", error);
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Failed to send message" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
