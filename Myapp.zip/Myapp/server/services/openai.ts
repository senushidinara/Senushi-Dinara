interface OpenAIMessage {
  role: "user" | "assistant" | "system";
  content: string;
}

interface OpenAIResponse {
  choices: Array<{
    message: {
      content: string;
      role: string;
    };
  }>;
}

export class OpenAIService {
  private apiKey: string;
  private baseUrl = "https://api.openai.com/v1";

  constructor() {
    this.apiKey = process.env.OPENAI_API_KEY || "";
    if (!this.apiKey) {
      console.warn("No OpenAI API key found in environment variables");
    }
  }

  async generateResponse(messages: OpenAIMessage[]): Promise<string> {
    if (!this.apiKey) {
      throw new Error("OpenAI API key not configured");
    }

    // Add system message for therapeutic context
    const systemMessage: OpenAIMessage = {
      role: "system",
      content: `You are Nero, a compassionate AI therapeutic journaling companion. Your role is to:
      
      1. Listen actively and empathetically to users' thoughts and feelings
      2. Ask thoughtful, open-ended questions that encourage self-reflection
      3. Validate emotions without judgment
      4. Gently guide users toward insights and coping strategies
      5. Use warm, supportive language that feels safe and understanding
      6. Never provide medical advice or diagnose mental health conditions
      7. Encourage professional help when appropriate
      8. Maintain therapeutic boundaries while being genuinely caring
      
      Remember: You're a supportive companion for self-reflection, not a replacement for professional therapy. Keep responses conversational, empathetic, and focused on helping the user process their thoughts and feelings.`
    };

    const allMessages = [systemMessage, ...messages];

    try {
      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${this.apiKey}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
          messages: allMessages,
          temperature: 0.7, // Balanced creativity and consistency
          max_tokens: 500, // Reasonable response length
          top_p: 0.9,
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error("OpenAI API Error:", response.status, errorText);
        throw new Error(`OpenAI API error: ${response.status} - ${errorText}`);
      }

      const data: OpenAIResponse = await response.json();
      
      if (!data.choices || data.choices.length === 0) {
        throw new Error("No response generated from OpenAI");
      }

      return data.choices[0].message.content.trim();
    } catch (error) {
      console.error("Error calling OpenAI API:", error);
      throw new Error(`Failed to generate AI response: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
}

export const openAIService = new OpenAIService();
