# Overview

This is a comprehensive therapeutic journaling system called "Nero" with two integrated components:

1. **Node.js Web Application**: A full-stack chat-style journaling app with AI-powered conversational interface for real-time therapeutic conversations
2. **Python Analytics Module**: Advanced neuroscience-powered text analysis that processes journal entries and saves structured psychological data to Notion databases

The system provides both immediate therapeutic support through AI conversations and long-term insights through automated psychological analysis and data tracking.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: shadcn/ui components built on Radix UI primitives with Tailwind CSS for styling
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Styling**: Tailwind CSS with custom therapeutic color palette (sage, cream, ocean themes)

## Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Design**: RESTful API structure with routes for conversations and messages
- **Error Handling**: Centralized error handling middleware with proper HTTP status codes
- **Development**: Hot reloading with tsx and Vite integration for development mode

## Data Storage

### Node.js Application Storage
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Design**: 
  - Conversations table for organizing chat sessions
  - Messages table for storing user and AI interactions
  - Users table for basic user management
- **Development Storage**: In-memory storage implementation for development/testing
- **Migrations**: Drizzle-kit for database schema management

### Python Analytics Storage
- **Notion Integration**: Automated saving of psychological analysis to Notion databases
- **Analysis Data**: Mood, energy levels, stress indicators, emotional tags, motivation extraction
- **Flexible Schema**: Works with existing Notion databases or can create structured analytics databases

## AI Integration

### Real-time Conversations (Node.js)
- **Service**: OpenAI API integration for AI response generation using GPT-4o
- **Therapeutic Context**: System prompts configured specifically for therapeutic journaling with empathetic, supportive responses
- **Response Processing**: Structured message handling with role-based conversations (user/assistant)

### Text Analysis (Python)
- **Psychological Analysis**: Advanced pattern matching for mood, energy, stress, and emotional state detection
- **Motivation Extraction**: Natural language processing to identify goals and intentions
- **Emotion Tagging**: Multi-dimensional emotional state classification
- **Supportive Responses**: Contextual therapeutic suggestions based on analysis results

## Authentication & Security
- **Session Management**: Connect-pg-simple for PostgreSQL-backed session storage
- **Environment Configuration**: Secure API key management through environment variables
- **CORS & Security**: Express middleware for request parsing and security headers

## Development Features
- **Code Quality**: TypeScript strict mode with comprehensive type checking
- **Build Process**: Separate client and server build processes with esbuild for production
- **Development Tools**: Replit integration with development banners and error overlays
- **Path Aliases**: Configured aliases for clean import statements (@/, @shared/, @assets/)

# External Dependencies

## AI Services
- **OpenAI API**: GPT-4o integration for generating therapeutic responses and conversation management
- **Python Text Analysis**: Custom psychological pattern matching and natural language processing

## Database Services
- **Neon Database**: Serverless PostgreSQL database service (@neondatabase/serverless) for chat data
- **Notion API**: External database integration for psychological analytics and long-term tracking
- **Connection**: Database URL-based connection configuration

## UI Component Library
- **Radix UI**: Comprehensive set of accessible UI primitives for React components
- **Tailwind CSS**: Utility-first CSS framework for styling
- **shadcn/ui**: Pre-built component library combining Radix UI with Tailwind CSS

## Development Tools
- **Replit Platform**: Cloud development environment with integrated tools
- **Vite**: Fast build tool and development server
- **Drizzle**: TypeScript ORM with schema validation using Zod
- **Python 3.11**: Analytics module runtime with notion-client, python-dotenv, requests

## Analytics Libraries
- **notion-client**: Python SDK for Notion API integration
- **python-dotenv**: Environment variable management for Python modules
- **Natural Language Processing**: Custom pattern matching for psychological indicators

## Additional Services
- **Date Handling**: date-fns library for date manipulation
- **Form Validation**: React Hook Form with Zod resolvers for type-safe form handling
- **Icons**: Lucide React for consistent iconography

# Recent Changes (January 6, 2025)
- Added Python analytics module with neuroscience-powered text analysis
- Integrated Notion API for automated psychological data tracking
- Created comprehensive mood, energy, stress, and emotion detection systems
- Built flexible analyzer that works with existing Notion databases
- Successfully tested full integration: journal entry → analysis → Notion storage
- Both systems now running: Node.js chat app + Python analytics module